﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace HF4
{
    public class PrQueue
    {
        private Element[] seq;
        public void SetEmpty() { seq = new Element[0]; }
        public bool isEmpty() { return seq.Length == 0;}
        public void Add(Element e)
        {
            seq = new Element[seq.Length+1];
            seq[seq.Length] = e;
        }
        public Element GetMax()
        {
            if (seq.Length == 0)
            {
                throw new Exception();
            }
            int max, ind;
            (max, ind) = MaxSelect();
            return seq[ind];
        }
        public void pop_back(Element[] array)
        {
            Array.Resize(ref array, array.Length - 1);
        }
        public Element RemMax()
        {
            if (seq.Length == 0)
            {
                throw new Exception();
            }
            int max, ind;
            (max, ind) = MaxSelect();
            Element e = seq[ind];
            seq[ind] = seq[seq.Length];
            pop_back(seq);
            return e;
        }
        private (int,int) MaxSelect()
        {
            if(seq.Length == 0)
            {
                throw new Exception();
            }
            int ind = 0;
            int max;
            max = seq[0].pr;
            for (int i = 0; i < seq.Length; i++)
            {
                if (seq[i].pr > max)
                {
                    ind = i;
                    max = seq[i].pr;
                }
            }
            return (max, ind);
        }
        /*private (int,int) MAX()
        {
            int ind = 0;
            int max;
            max = seq[0].pr;
            for(int i = 0; i < seq.Length ; i++)
            {
                if (seq[i].pr > max)
                {
                    ind = i;
                    max = seq[i].pr;
                }
            }
            return (max,ind);
        }*/
    } 
}
