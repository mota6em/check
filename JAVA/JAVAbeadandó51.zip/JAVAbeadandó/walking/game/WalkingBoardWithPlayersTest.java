package walking.game;
import walking.game.util.Direction;

import static check.CheckThat.*;
import static org.junit.jupiter.api.Assertions.*;

import java.beans.Transient;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.*;
import org.junit.jupiter.api.extension.*;
import org.junit.jupiter.params.*;
import org.junit.jupiter.params.provider.*;
import check.*;
import walking.game.util.Direction;

public class WalkingBoardWithPlayersTest {
    @Test 
    public void walk1(){
        int[][] matrix = {
            {0,77,2,4},
            {5,6,6,5},
            {2,9,9,4}
        };
        int[] steps = {1,1,5,1};
        // WalkingBoard wb = new WalkingBoard(matrix);
        WalkingBoardWithPlayers wbWithPlayers = new WalkingBoardWithPlayers(matrix, 2);
        int[] playersScores = wbWithPlayers.walk(steps);
        assertEquals(3,playersScores[0]);
        assertEquals(9,playersScores[1]);
        assertEquals(2,wbWithPlayers.getTiles()[0][1]);
        // assertEquals(3,wbWithPlayers.getTiles()[1][0]);
        assertEquals(7,wbWithPlayers.getTiles()[1][1]);
    }
}