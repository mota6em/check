package walking.game;

import walking.game.player.Player;

public class WalkingBoardWithPlayers extends WalkingBoard {
    private walking.game.player.Player[] players;
    private int round;
    public static final int SCORE_EACH_STEP = 13;
    public WalkingBoardWithPlayers(int[][] board, int playerCount){
        super(board);
        if(playerCount < 2)
        {
            throw new IllegalArgumentException("Number of players is less than 2!");
        }
        initPlayers(playerCount);
    }
    public WalkingBoardWithPlayers(int size,int playerCount){
        super(size);
        if(playerCount < 2)
        {
            throw new IllegalArgumentException("Number of players is less than 2!");
        }
        initPlayers(playerCount);
    }

    //here starats the shitt

    
    private void initPlayers(int playerCount){
        players = new Player[playerCount];
        players[0] = new MadlyRotatingBuccaneer();
        for (int i = 1; i < playerCount; i++) {
            players[i] = new Player(); // A többi játékos egyszerű Player
        }
        round = 0; // Kezdetben az első játékos kezd.
    }
    
    public int[] walk(int... stepCounts) {
        int[] playerScores = new int[players.length]; // A játékosok pontszámait tároló tömb inicializálása
    
        for (int i = 0; i < stepCounts.length; i++) { // Végigmegyünk az összes lépésszámon
            Player currentPlayer = players[i % players.length]; // A soron következő játékos kiválasztása
            int steps = stepCounts[i]; // Az aktuális lépésszám lekérése
    
            // A játékos fordul egyet és megy a megfelelő irányba
            currentPlayer.turn();
            currentPlayer.move(steps);
    
            // A tábláról olvasott értékkel növeljük a játékos pontszámát
            int boardValue = getBoardValueAt(currentPlayer.getPosition());
            currentPlayer.addToScore(boardValue);
    
            // A játékos pontszámát hozzáadjuk a visszatérési tömbhöz
            playerScores[i % players.length] = currentPlayer.getScore();
        }
    
        return playerScores; // A játékosok pontszámai tömb visszaadása
    }
    
}
